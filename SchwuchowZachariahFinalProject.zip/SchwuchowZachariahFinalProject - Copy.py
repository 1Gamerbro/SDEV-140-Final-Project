import tkinter as tk

#Variables for Options Selected
MSP = None #Variable of the Multi-Service Purchase
CP = None #Variable of the Contract Purchase

#Functions to set the variables for the options selected
def MultiServicePurchase():
    return MSP == True
def ContractPurchase():
    return CP == True
def ClearPur():
    MSP = None
    CP = None



def main(): 
    #Creates window and set size and label
    window = tk.Tk() #Creates a window
    window.title("Cyber Security Services Purchaser")#Labels Window
    window.geometry("1000x1000") #Sets the windows size

    #Set Grid
    window.columnconfigure([0,1,2] , weight=1)
    window.rowconfigure([0,1,2], weight=1)


    #Button Creations for Options 
    MSP = tk.Button(text ="Multi-Service Purchase", command = MultiServicePurchase, bg= 'red') # MultiServicePurchase button
    MSP.grid(row= 0 , column= 0) #MultiServicePurchase button set to grid
    CP = tk.Button(text ="Contract Purchase", command = ContractPurchase) # Contract Purchase button
    CP.grid(row= 0 , column= 2) #Contract Purchase button set to grid
    Clear = tk.Button(text ="Clear Purchase Selections", command = ClearPur) # Contract Purchase button
    Clear.grid(row= 0 , column= 1) #Clear Purchase button set to grid

    #Label for the Options
    PurChoice = tk.Label(text = "Choose your Preferred Purchase Type") #Label for the preferred type of purchase
    PurChoice.grid(row= 0, column= 1, sticky="N") #assigns the label to the grid

    window.mainloop()

#Calls main function / Starts Program
if __name__ == "__main__":
    main()
