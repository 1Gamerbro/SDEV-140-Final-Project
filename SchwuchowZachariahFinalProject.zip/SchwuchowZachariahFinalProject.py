import tkinter as tk

#Variables for Options Selected
MSP = None #Variable of the Multi-Service Purchase
CP = None #Variable of the Contract Purchase
PT = None #Variable of the Penetration Test Purchase
SA = None #Variable of the Server Analysis Purchase
ET = None #Variable of the employee Training Purchase

#Functions to set the variables for the options selected
def MultiServicePurchase(): #Function of the Multi-Service Purchase
    return MSP == True
def ContractPurchase(): #Function of the Contract Purchase
    return CP == True
def PTPurchase(): #Function of the Penetration Test Purchase
    return PT == True
def SAPurchase(): #Function of the Server Analysis Purchase
    return SA == True
def ETPurchase(): #Function of the employee Training Purchase
    return ET == True
def ClearPur():
    MSP = None
    CP = None
def ClearSER():
    PT = None #Variable of the Penetration Test Purchase reset
    SA = None #Variable of the Server Analysis Purchase reset
    ET = None #Variable of the employee Training Purchase reset
def ClearALL():
    MSP = None #Variable of the Multi-Service Purchase reset
    CP = None #Variable of the Contract Purchase reset
    PT = None #Variable of the Penetration Test Purchase reset
    SA = None #Variable of the Server Analysis Purchase reset
    ET = None #Variable of the employee Training Purchase reset

def SecondWin():
#==============================================================================================================================
    def submit2():
        #Gets the variables for the three entry Fields of the second window
        name =  NAME.get()
        ADDRESS =  Address.get()
        CompanyName =  COMPANYNAME.get()

        #Prints out all the variables to terminal to show the results
        print("Name: ", name)
        print("Address: ", ADDRESS)
        print("Company Name: ", CompanyName)
        print('Your Order has been placed! Thank you and you may close out of the windows!')
#==============================================================================================================================
    #Variables for NAME / ADDRESS / COMPANY NAME
    #Creates window and set size and label
    window2 = tk.Tk() #Creates a window
    window2.title("Cyber Security Services Purchaser")#Labels Window
    window2.geometry("400x300") #Sets the windows size
#==============================================================================================================================
    #Set Grid
    window2.columnconfigure([0,1] , weight=1)
    window2.rowconfigure([0,1,2,3], weight=1)
#==============================================================================================================================    
# #Button Creations for Options 
    NAME = tk.Entry(window2) # MultiServicePurchase button
    NAME.grid(row= 0 , column= 1) # MultiService Purchase button set to grid
    Address = tk.Entry(window2) # MultiServicePurchase button
    Address.grid(row= 1 , column= 1) # MultiService Purchase button set to grid
    COMPANYNAME = tk.Entry(window2) # MultiServicePurchase button
    COMPANYNAME.grid(row= 2 , column= 1) # MultiService Purchase button set to grid
#==============================================================================================================================    
# #Label for the Options
    NAMELABEL = tk.Label(window2, text = "Name:") #Label for the  name entry
    NAMELABEL.grid(row= 0, column= 0) #assigns the label to the grid
    ADDRESSLABEL = tk.Label(window2, text = "Address:") #Label for the Address entry
    ADDRESSLABEL.grid(row= 1, column= 0) #assigns the label to the grid
    COMPANYNAMELABEL = tk.Label(window2, text = "Company Name:") #Label for the company name entry
    COMPANYNAMELABEL.grid(row= 2, column= 0) #assigns the label to the grid
#==============================================================================================================================
    SUBMIT2 = tk.Button(window2, text ="SUBMIT", bg = "Green", fg="white" , command = submit2) # Contract Purchase button
    SUBMIT2.grid(row= 3 , column= 1)
#==============================================================================================================================
    window2.mainloop()



def main(): 
    #Creates window and set size and label
    window = tk.Tk() #Creates a window
    window.title("Cyber Security Services Purchaser")#Labels Window
    window.geometry("1000x1000") #Sets the windows size
#==============================================================================================================================
    #Set Grid
    window.columnconfigure([0,1,2] , weight=1)
    window.rowconfigure([0,1,2], weight=1)
#==============================================================================================================================
    #Button Creations for Options 
    MSP = tk.Button(text ="Multi-Service Purchase", command = MultiServicePurchase, bg = "Dark Blue", fg="white") # MultiServicePurchase button
    MSP.grid(row= 0 , column= 0) #MultiServicePurchase button set to grid
    CP = tk.Button(text ="Contract Purchase", command = ContractPurchase, bg = "Dark Blue", fg="white") # Contract Purchase button
    CP.grid(row= 0 , column= 2) #Contract Purchase button set to grid
    Clear = tk.Button(text ="Clear Purchase Selections", command = ClearPur, bg = "Red", fg="white") # Clear Purchase button
    Clear.grid(row= 0 , column= 1) #Clear Purchase button set to grid
#==============================================================================================================================
    PT = tk.Button(text ="Penetration Test Service", command = PTPurchase, bg = "Blue", fg="white") # Penetration Test button
    PT.grid(row= 1 , column= 0) #Penetration Test button set to grid
    SA = tk.Button(text ="Server Analysis Service", command = SAPurchase, bg = "Blue", fg="white") # Server Analysis button
    SA.grid(row= 1 , column= 1) #Server Analysis button set to grid
    ET = tk.Button(text ="Employee Training Service", command = ETPurchase, bg = "Blue", fg="white") # Employee Training button
    ET.grid(row= 1 , column= 2) #Employee Training button set to grid
#==============================================================================================================================
    ClearSERVICE = tk.Button(text ="Clear Service Selections", command = ClearSER, bg = "red", fg="white") # Clear Service button
    ClearSERVICE.grid(row= 2 , column= 2) #Clear Service button set to grid
    ClearALLPUR = tk.Button(text ="Clear ALL Selections", command = ClearALL, bg = "red", fg="white") # Clear ALL button
    ClearALLPUR.grid(row= 2 , column= 0) #Clear ALL button set to grid
    SUBMIT = tk.Button(text ="SUBMIT", command = SecondWin, bg = "Green", fg="white") # Contract Purchase button
    SUBMIT.grid(row= 2 , column= 1) #Clear Purchase button set to grid
#==============================================================================================================================
    #Label for the Options
    PurChoice = tk.Label(text = "Choose your Preferred Purchase Type") #Label for the preferred type of purchase
    PurChoice.grid(row= 0, column= 1, sticky="N") #assigns the label to the grid
    SERChoice = tk.Label(text = "Choose your Services") #Label for the preferred type of purchase
    SERChoice.grid(row= 1, column= 1, sticky="N") #assigns the label to the grid
#==============================================================================================================================
    window.configure(background='SteelBlue1') #Configure the window to have a background color
#==============================================================================================================================
    window.mainloop() #starts the main window

#Calls main function / Starts Program
if __name__ == "__main__":
    main()
